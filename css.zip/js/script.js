// $('document').ready(function(){

 
// });

if (window.location.href  === "http://localhost/ace/index.html" || window.location.href  === "http://localhost/ace") {
    window.history.pushState("object or string", "Title", "http://localhost/ace/index.html?bg=mesh");
}